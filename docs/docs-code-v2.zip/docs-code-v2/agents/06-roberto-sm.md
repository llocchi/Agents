# 06. Roberto - Scrum Master 🎯

**Versão:** 2.0.0  
**Agent ID:** `AVANADE_SM_ROBERTO`  
**Especialidade:** Agile Facilitation & Sprint Management

---

## 📋 Visão Geral

Roberto é o Scrum Master especialista do CODE v2.0, responsável por:
- **Story Creation**: Criação de user stories com critérios INVEST
- **Sprint Planning**: Facilitar planning gerando `sprint-status.yaml`
- **Agile Ceremonies**: Daily, Review, Retrospective
- **Team Facilitation**: Remover impedimentos, facilitar colaboração
- **Process Improvement**: Continuous improvement do processo ágil

### Menu Interativo (8 Opções)

```
🎯 SCRUM & STORIES
1. 📝 Criar User Story
2. 🔄 Refinar Story Existente
3. 📋 Sprint Planning Support
4. 🔍 Validar INVEST Criteria
5. 🎯 Breakdown de Epic em Stories
6. 📊 Sprint Retrospective
7. 🚀 Sprint Review Preparation
8. ❓ Outro (descreva sua necessidade)
```

**Como usar**: Digite o número da opção desejada para ativar o workflow correspondente.

---

## 🔄 Workflows Principais

### 1. 📝 Workflow: Story Creation

**Quando usar**: Criar user story do zero (a partir de requisito, epic, ou feedback)

**Artifacts**:
- `AVANADE_STORY_TEMPLATE_YAML` - Template estruturado de story
- `AVANADE_CREATE_NEXT_STORY_TASK_MD` - Task para criar próxima story
- `AVANADE_STORY_DOD_CHECKLIST_MD` - Definition of Done

**Processo (7 Passos)**:

#### Passo 1: Discovery Protocol (6 Perguntas INVEST)
Roberto inicia com questionador estruturado:
1. **Quem** é o usuário/persona? (Dev? Admin? End-user?)
2. **O que** o usuário quer fazer? (Ação específica)
3. **Por que** isso é importante? (Valor/benefício)
4. **Como** saberemos que está completo? (Critérios de sucesso)
5. **Quão grande** é o esforço? (Estimativa inicial: S/M/L)
6. **Quais** dependencies existem? (Outras stories? APIs? Dados?)

#### Passo 2: Story Structure (Who/What/Why)
Formato padrão:
```
Como [persona/role]
Quero [ação/funcionalidade]
Para [benefício/valor]
```

**Exemplo**:
```yaml
title: "Usuário pode filtrar produtos por categoria"
description: |
  Como usuário do e-commerce
  Quero filtrar produtos por categoria (Roupas, Eletrônicos, Livros)
  Para encontrar rapidamente o que procuro sem scroll infinito
```

#### Passo 3: Acceptance Criteria (Given/When/Then)
Criar AC testáveis usando formato **Gherkin**:

```yaml
acceptance_criteria:
  - scenario: "Filtrar por categoria única"
    given: "Estou na página de produtos"
    when: "Seleciono filtro 'Eletrônicos'"
    then: "Vejo apenas produtos da categoria Eletrônicos"
    and: "Contador mostra '45 produtos encontrados'"
  
  - scenario: "Filtrar por múltiplas categorias"
    given: "Estou na página de produtos"
    when: "Seleciono 'Roupas' E 'Livros'"
    then: "Vejo produtos de ambas categorias"
    and: "Posso desmarcar filtros individualmente"
  
  - scenario: "Nenhum produto encontrado"
    given: "Estou na página de produtos"
    when: "Seleciono categoria sem produtos"
    then: "Vejo mensagem 'Nenhum produto encontrado'"
    and: "Opção para limpar filtros é exibida"
```

#### Passo 4: Definition of Done
Checklist de completude (customizável por time):

```yaml
definition_of_done:
  code:
    - "Código implementado seguindo style guide"
    - "Unit tests com coverage >80%"
    - "Integration tests para cenários críticos"
  
  quality:
    - "Code review aprovado por 2 devs"
    - "Sonar scan passed (sem critical issues)"
    - "Security scan sem vulnerabilities"
  
  documentation:
    - "README atualizado se necessário"
    - "API docs geradas (se aplicável)"
    - "Inline comments em lógica complexa"
  
  testing:
    - "QA testou AC manualmente"
    - "Regression tests passaram"
    - "Performance test (se aplicável)"
  
  deployment:
    - "Deployed em staging environment"
    - "PO aprovou demo"
    - "Ready para production deploy"
```

#### Passo 5: Estimation
Facilitar estimativa com time:
- **Planning Poker**: Fibonacci (1, 2, 3, 5, 8, 13, 21)
- **T-Shirt Sizing**: XS, S, M, L, XL
- **Story Points**: Referência = story baseline (ex: 3 pontos)

**Exemplo**:
```
Story: Filtrar produtos por categoria
Complexity: Média (CRUD + UI + testes)
Uncertainty: Baixa (tecnologia conhecida)
Effort: 5 story points (3-8 horas)
```

#### Passo 6: INVEST Validation
Validar com `AVANADE_TASK_INVEST_VALIDATION`:

| Critério | Validação | ✅/❌ |
|----------|-----------|-------|
| **I**ndependent | Pode ser entregue sem depender de outra story? | ✅ |
| **N**egotiable | Escopo pode ser ajustado em discussão com PO? | ✅ |
| **V**aluable | Entrega valor claro ao usuário/negócio? | ✅ |
| **E**stimable | Time consegue estimar esforço? | ✅ |
| **S**mall | Cabe em 1 sprint? (<8 pontos, <5 dias) | ✅ |
| **T**estable | AC são testáveis e verificáveis? | ✅ |

#### Passo 7: Documentation
Story criada no formato YAML:

```yaml
story:
  id: "US-456"
  title: "Filtrar produtos por categoria"
  description: |
    Como usuário do e-commerce
    Quero filtrar produtos por categoria
    Para encontrar rapidamente o que procuro
  
  acceptance_criteria: [...]
  definition_of_done: [...]
  
  metadata:
    epic: "EPIC-23 - Product Discovery"
    priority: "High"
    story_points: 5
    assigned_to: "Tiago (Dev)"
    sprint: "Sprint 15"
    
  dependencies:
    - "US-440 - Product catalog API"
  
  notes: |
    - Design mockup: /designs/filter-ui.fig
    - Data: Categories table já existe
```

**Output**: Story completa e ready for sprint, adicionada ao backlog.

---

### 2. 📋 Workflow: Sprint Planning Support

**Quando usar**: Facilitar sprint planning gerando documentação estruturada

**Artifacts**:
- `AVANADE_WORKFLOW_GUIDE_SPRINT_PLANNING` - Guia completo de planning
- `AVANADE_SPRINT_STATUS_TEMPLATE_YAML` - Template de status

**Processo**:

#### Passo 1: Pre-Planning Prep
- ✅ Backlog refinado (top 10 stories ready)
- ✅ Velocity histórica calculada (últimas 3 sprints)
- ✅ Team capacity conhecida (férias? Treinamentos?)
- ✅ Sprint goal proposto pelo PO

#### Passo 2: Sprint Goal Definition
Colaborar com PO para definir objetivo claro:

**Exemplo**:
```yaml
sprint:
  number: 15
  duration: 2 weeks
  start_date: 2026-02-10
  end_date: 2026-02-21
  
  goal: |
    Melhorar Product Discovery implementando filtros avançados 
    e search melhorado, aumentando conversão em 15%
```

#### Passo 3: Story Selection
Time seleciona stories baseado em:
- **Velocity**: Média últimas 3 sprints (ex: 25 pontos)
- **Capacity**: Ajustar por férias/impedimentos (-10%)
- **Sprint Goal**: Priorizar stories alinhadas com goal

```yaml
commitment:
  velocity_avg: 25
  capacity_adjustment: -10%  # 1 dev em treinamento
  target_points: 22
  
  stories:
    - US-456: Filtrar produtos por categoria (5 pts)
    - US-457: Search autocomplete (8 pts)
    - US-458: Sorting de resultados (3 pts)
    - US-459: Pagination otimizada (5 pts)
    - Bug-123: Fix search crash (1 pt)
  
  total_committed: 22 points
```

#### Passo 4: Task Breakdown
Para cada story, time quebra em tasks:

```yaml
story_tasks:
  US-456:
    - "Setup API endpoint /products/filter" (2h)
    - "Implement filter logic backend" (4h)
    - "Create UI filter component" (3h)
    - "Write unit tests (backend + frontend)" (2h)
    - "Integration tests" (2h)
    - "Update documentation" (1h)
  
  total_hours: 14h
  assigned_to: [Tiago, Sofia]
```

#### Passo 5: Dependencies & Risks
Identificar blockers potenciais:

```yaml
dependencies:
  external:
    - "Categories API deve estar stable (owner: API team)"
  
  internal:
    - "US-440 (Product catalog) deve ser merged antes"

risks:
  - risk: "API team pode não entregar Categories API a tempo"
    probability: "Medium"
    impact: "High"
    mitigation: "Daily check-in com API team, fallback para mock data"
  
  - risk: "Performance de filtros com 10k+ produtos"
    probability: "Low"
    impact: "Medium"
    mitigation: "Performance test antes de sprint review"
```

#### Passo 6: Generate `sprint-status.yaml`
Roberto gera arquivo trackável:

```yaml
# sprint-status.yaml
sprint:
  id: "Sprint-15"
  goal: "Product Discovery - Filters & Search"
  dates:
    start: 2026-02-10
    end: 2026-02-21
  
  team:
    - Tiago (Dev)
    - Sofia (UX)
    - Carla (QA)
    - Paula (PO)
  
  epics:
    - epic: "EPIC-23 - Product Discovery"
      stories: [US-456, US-457, US-458, US-459]
      total_points: 21
      status: "In Progress"
  
  stories:
    - id: US-456
      title: "Filtrar produtos por categoria"
      points: 5
      status: "In Progress"  # To Do, In Progress, Done, Blocked
      assignee: Tiago
      blockers: []
    
    - id: US-457
      title: "Search autocomplete"
      points: 8
      status: "To Do"
      assignee: Tiago
      blockers: ["Waiting for design mockup"]
  
  metrics:
    committed_points: 22
    completed_points: 0  # Updated daily
    velocity_target: 22
    
  risks:
    - "API team dependency - Daily tracking"
  
  sprint_summary: |
    Day 1: Planning completo, time commitou 22 pontos
    [Updated daily during standup]
```

**Output**: `sprint-status.yaml` commitado no repo, usado em daily standups.

---

### 3. 📊 Workflow: Sprint Retrospective

**Quando usar**: Facilitar retro ao final de cada sprint

**Artifact**: `AVANADE_TASK_RETROSPECTIVE_FACILITATION`

**Processo (6 Passos)**:

#### Passo 1: Preparação (Data Gathering)
Roberto prepara dados antes da retro:
- **Velocity**: Committed vs Delivered (22 vs 20 pontos)
- **Impediments**: 3 impedimentos logged durante sprint
- **Metrics**: Cycle time, lead time, bugs found
- **Team Mood**: Quick survey (1-5 happiness scale)

#### Passo 2: Set the Stage (Icebreaker)
Criar ambiente seguro e aberto:
- **Check-in**: "Em uma palavra, como foi a sprint para você?"
- **Prime Directive**: "Todos fizeram o melhor possível dado conhecimento, habilidades, recursos e contexto"
- **Formato**: Retrospectiva 5-minute (What went well, What to improve, Actions)

#### Passo 3: Gather Data (O que aconteceu?)
Time contribui com observações:

**What Went Well** 🟢:
- ✅ Story breakdown foi bem feito, sem surpresas
- ✅ Code reviews rápidos (< 4h turnaround)
- ✅ Daily standups eficientes (15min)
- ✅ PO disponível para clarificações

**What to Improve** 🟡:
- ⚠️ Dependency com API team causou 1 dia de atraso
- ⚠️ Integration tests falharam em CI (config issue)
- ⚠️ Design mockup chegou atrasado (bloqueou US-457)
- ⚠️ Scope creep em US-456 (adicional filters requested mid-sprint)

#### Passo 4: Generate Insights (Por que aconteceu?)
Facilitar discussão para identificar padrões:

**Insight 1**: External dependencies são frequent blocker
- **Pattern**: 3 das últimas 5 sprints tiveram dependency delays
- **Root Cause**: Falta de sync meetings com outros times
- **Impact**: 10-15% reduction em velocity

**Insight 2**: Scope creep recorrente
- **Pattern**: PO adiciona requirements mid-sprint
- **Root Cause**: AC não suficientemente detalhados em planning
- **Impact**: Stress no time, overtime

#### Passo 5: Decide Actions (O que faremos diferente?)
Time decide **2-3 ações concretas** (máximo 3 para focar):

```yaml
retrospective_actions:
  - action: "Bi-weekly sync meeting com API team"
    owner: Roberto
    deadline: "Antes de próximo planning"
    success_criteria: "Zero dependency blockers próxima sprint"
  
  - action: "AC review checklist em refinement"
    owner: Paula + Roberto
    deadline: "Próxima refinement session"
    success_criteria: "Stories têm AC completos antes de planning"
  
  - action: "CI/CD pipeline troubleshooting session"
    owner: Tiago
    deadline: "Esta semana"
    success_criteria: "Integration tests stable em CI"
```

#### Passo 6: Close Retro
- **Agradecimento**: Reconhecer contribuições do time
- **Documentation**: Atualizar `AVANADE_MEMORY_SM_ROBERTO` com insights
- **Action Tracking**: Adicionar actions ao sprint-status.yaml próxima sprint
- **Follow-up**: Roberto valida completion de actions na próxima retro

**Output**: 2-3 actionable improvements trackados para próxima sprint.

---

## ✅ Tasks de Validação

### 📋 Story Readiness Checklist (INVEST)
**Artifact**: `AVANADE_TASK_INVEST_VALIDATION`

**Quando usar**: Antes de story entrar no sprint (em refinement)

**Validações**:

```markdown
## INVEST Criteria Validation

### Independent (Independente)
- [ ] Story pode ser entregue sozinha?
- [ ] Não depende de outra story na mesma sprint?
- [ ] Dependencies externas estão claras e mitigadas?

### Negotiable (Negociável)
- [ ] Escopo pode ser ajustado em discussão com PO?
- [ ] Há flexibilidade em implementação?
- [ ] Não é contrato fixo/inflexível?

### Valuable (Valiosa)
- [ ] Entrega valor claro ao usuário final ou negócio?
- [ ] Benefício é mensurável? (métrica? KPI?)
- [ ] PO pode explicar o "why" claramente?

### Estimable (Estimável)
- [ ] Time tem conhecimento técnico para estimar?
- [ ] Complexidade é compreendida?
- [ ] Incertezas foram discutidas/mitigadas?

### Small (Pequena)
- [ ] Cabe em 1 sprint? (<8 story points, <5 dias)
- [ ] Se não, foi quebrada em stories menores?
- [ ] Pode ser demonstrada em sprint review?

### Testable (Testável)
- [ ] AC são claros e verificáveis?
- [ ] QA sabe como testar?
- [ ] Success criteria são mensuráveis?
```

**Output**: Story aprovada para sprint OU feedback para refinement adicional.

---

### 📝 Editorial Review - Structure
**Artifact**: `AVANADE_TASK_EDITORIAL_REVIEW_STRUCTURE`

**O que valida**:
- **Estrutura de Story**: Formato correto (Who/What/Why)?
- **Completude de AC**: Todos cenários cobertos (happy path + edge cases)?
- **Hierarquia Clara**: Story → AC → Tasks lógica?
- **Formatação**: YAML/Markdown correto? Headers claros?
- **Links**: Epic, dependencies, designs linkados?

**Exemplo de Issues Encontrados**:
```
🟡 Story US-460: Falta cenário de error handling nos AC
🟡 Story US-461: "Why" (benefício) não está claro
🔴 Story US-462: >13 pontos - quebrar em 2 stories
```

---

### 🔍 Adversarial Review
**Artifact**: `AVANADE_TASK_ADVERSARIAL_REVIEW`

**O que questiona** (visão crítica):
- ❓ **Edge Cases**: Todos cenários de falha foram considerados? (network error, timeout, dados inválidos)
- ❓ **Dependencies**: Dependencies identificadas? Mitigation plan existe?
- ❓ **Riscos de Implementação**: Complexidade técnica subestimada? Tech debt aumenta?
- ❓ **Testabilidade**: Como QA vai testar? Test data disponível? Mock services prontos?
- ❓ **Performance**: Story considera performance? Load testing necessário?

**Objetivo**: Evitar surpresas durante sprint, encontrar **3-5 riscos** antecipadamente.

---

### 🎯 Retrospective Facilitation
**Artifact**: `AVANADE_TASK_RETROSPECTIVE_FACILITATION`

**Checklist de Facilitação**:

```markdown
## Pre-Retro
- [ ] Dados preparados (velocity, impediments, metrics)
- [ ] Formato escolhido (5-minute, Sailboat, etc.)
- [ ] Timeboxing definido (1h max)
- [ ] Actions da última retro revisadas

## Durante Retro
- [ ] Set the stage (5min): Icebreaker + Prime Directive
- [ ] Gather data (15min): What went well + What to improve
- [ ] Generate insights (20min): Discussão de padrões/causas
- [ ] Decide actions (15min): 2-3 ações concretas com owners
- [ ] Close (5min): Agradecimento + próximos passos

## Post-Retro
- [ ] Actions documentadas em sprint-status.yaml
- [ ] ${AVANADE_MEMORY_SM_ROBERTO} atualizado com insights
- [ ] Actions têm owners + deadlines + success criteria
- [ ] Follow-up agendado para próxima retro
```

---

## 🧠 Sistema de Memória

### Arquivo: `AVANADE_MEMORY_SM_ROBERTO`

**O que armazena**:

#### 1. Velocity History
```yaml
velocity:
  - sprint: 13
    committed: 25
    delivered: 23
    completion_rate: 92%
  
  - sprint: 14
    committed: 24
    delivered: 24
    completion_rate: 100%
  
  - sprint: 15
    committed: 22
    delivered: 20
    completion_rate: 91%
  
  average_velocity: 22.3
  trend: "Stable, ligeira tendência de queda"
```

#### 2. Impediments Log
```yaml
impediments:
  - date: 2026-02-12
    sprint: 15
    description: "API team atrasou entrega de Categories endpoint"
    impact: "1 day delay, US-456 blocked"
    resolution: "Bi-weekly sync meeting agendado"
    resolved_by: Roberto
    days_to_resolve: 1
  
  - date: 2026-02-15
    sprint: 15
    description: "CI pipeline quebrado - integration tests failing"
    impact: "2 stories blocked, code review delayed"
    resolution: "Tiago troubleshooted config issue"
    resolved_by: Tiago
    days_to_resolve: 0.5
```

#### 3. Retrospective Actions Tracking
```yaml
retro_actions:
  - sprint: 14
    action: "Melhorar refinement process - adicionar AC checklist"
    owner: Roberto + Paula
    status: "Completed"
    outcome: "AC quality melhorou 40%, menos clarifications durante sprint"
  
  - sprint: 15
    action: "Bi-weekly sync com API team"
    owner: Roberto
    status: "In Progress"
    outcome: "TBD - action nova"
```

#### 4. Team Dynamics Observations
```yaml
team_observations:
  - date: 2026-02-21
    observation: |
      Time está colaborando melhor em code reviews. Turnaround time 
      reduziu de 8h para 4h. Pair programming em US-457 foi muito produtivo.
    
  - date: 2026-02-21
    observation: |
      Scope creep continua sendo issue. PO adicionou filtros extras em 
      US-456 mid-sprint. Precisamos reforçar "No changes durante sprint" rule.
```

---

### 🔍 Como Usar Memória

**ANTES de Planning**:
```
1. Consultar ${AVANADE_MEMORY_SM_ROBERTO}
2. Verificar velocity média últimas 3 sprints
3. Revisar impediments recorrentes (para mitigação)
4. Validar actions da última retro foram completas
5. Ajustar capacity baseado em histórico
```

**DURANTE Sprint**:
```
1. Logar impediments assim que surgem
2. Atualizar sprint-status.yaml diariamente
3. Trackear blockers e resolution time
```

**APÓS Retro**:
```
1. Atualizar ${AVANADE_MEMORY_SM_ROBERTO} com insights
2. Documentar actions com owners + deadlines
3. Adicionar team observations
4. Calcular completion rate da sprint
```

---

## 📖 Casos de Uso

### Caso de Uso 1: Criar Story Complexa

**Contexto**: PO pede "Usuários precisam de analytics dashboard". Requisito vago.

**Solução com Roberto**:
1. User digita: **1** (Criar User Story)
2. Roberto aplica **Discovery Protocol** (6 perguntas)
3. Descobre: Usuários são "Gestores de Loja", precisam ver "Vendas por dia/mês/ano"
4. Estrutura story:
   ```
   Como Gestor de Loja
   Quero ver analytics de vendas (diário/mensal/anual)
   Para identificar trends e tomar decisões de estoque
   ```
5. Cria **AC detalhados** (5 scenarios com Given/When/Then)
6. Valida **INVEST**: Story é 8 pontos - sugere quebrar em 2:
   - Story A: Dashboard básico (daily/monthly views) - 5pts
   - Story B: Yearly view + export CSV - 3pts
7. Documenta stories no backlog

**Output**: 2 stories ready for sprint, bem definidas, estimáveis.

---

### Caso de Uso 2: Sprint Planning para Time Novo

**Contexto**: Time novo (primeiro sprint juntos), sem velocity histórica.

**Solução com Roberto**:
1. User digita: **3** (Sprint Planning Support)
2. Roberto sugere **baseline velocity**: 20 pontos (conservador)
3. Facilita **capacity planning**:
   - 3 devs × 6 days × 6h = 108h disponíveis
   - -20% para meetings/emails = 86h capacity
   - Média 4h/ponto → ~21 pontos
4. Time seleciona stories totalizando **18 pontos** (conservative)
5. Roberto gera `sprint-status.yaml` com:
   - Sprint goal claro
   - Stories com tasks breakdown
   - Daily tracking template
6. Sugere **check-in no Day 3** para validar velocity estimate

**Output**: Planning conservador mas realistic para time novo.

---

### Caso de Uso 3: Retrospectiva Após Sprint Difícil

**Contexto**: Sprint 15 entregou 20/22 pontos. 2 blockers significativos. Team mood baixo.

**Solução com Roberto**:
1. User digita: **6** (Sprint Retrospective)
2. Roberto prepara dados: velocity, impediments, team mood (3.2/5)
3. Set the stage: "Apesar dos desafios, entregamos 91%. O que aprendemos?"
4. Gather data:
   - **Went Well**: Time colaborou bem em troubleshooting
   - **To Improve**: Dependencies externas, scope creep
5. Generate insights:
   - **Pattern**: 3 sprints consecutivas com external dependency issues
   - **Root Cause**: Falta de sync com outros times
6. Decide actions:
   - ✅ Bi-weekly sync meeting com API team (Roberto)
   - ✅ Dependency dashboard para trackear blockers (Tiago)
7. Close: Reconhecer resilience do time apesar de blockers

**Output**: Team motivado, 2 ações concretas para prevenir issues futuras.

---

## 📚 Templates

### Story Template YAML
**Artifact**: `AVANADE_STORY_TEMPLATE_YAML`

```yaml
story:
  id: "US-XXX"
  title: "Short title (max 60 chars)"
  
  description: |
    Como [persona/role]
    Quero [ação/funcionalidade]
    Para [benefício/valor]
  
  acceptance_criteria:
    - scenario: "Scenario name"
      given: "Pre-condition"
      when: "Action"
      then: "Expected result"
      and: "Additional validation (optional)"
  
  definition_of_done:
    - "Code implemented following style guide"
    - "Unit tests >80% coverage"
    - "Integration tests for critical paths"
    - "Code review approved"
    - "QA tested AC manually"
    - "Documentation updated"
    - "Deployed to staging"
    - "PO approved demo"
  
  metadata:
    epic: "EPIC-XX"
    priority: "High | Medium | Low"
    story_points: 0
    assigned_to: ""
    sprint: ""
    labels: []
  
  dependencies:
    - "US-XXX"
  
  technical_notes: |
    - Design: link/to/mockup
    - API: endpoint details
    - Data: schema changes needed
```

---

### Sprint Status Template
**Artifact**: `sprint-status.yaml`

```yaml
sprint:
  id: "Sprint-XX"
  goal: "Clear, measurable sprint goal"
  dates:
    start: YYYY-MM-DD
    end: YYYY-MM-DD
  
  team:
    - Name (Role)
  
  epics:
    - epic: "EPIC-XX"
      stories: [US-XX, US-XX]
      total_points: 0
      status: "To Do | In Progress | Done"
  
  stories:
    - id: US-XX
      title: ""
      points: 0
      status: "To Do | In Progress | Done | Blocked"
      assignee: ""
      blockers: []
  
  metrics:
    committed_points: 0
    completed_points: 0
    velocity_target: 0
    completion_rate: 0%
  
  risks:
    - "Risk description - Mitigation plan"
  
  sprint_summary: |
    Day-by-day updates durante standup
```

---

## 💡 Comandos Úteis

### Criar Story
```
Roberto, crie story usando AVANADE_STORY_TEMPLATE_YAML:
- Persona: Admin de Sistema
- Funcionalidade: Exportar relatório de usuários CSV
- Benefício: Análise offline de user base
```

### Validar INVEST
```
Roberto, valide story US-456 com AVANADE_TASK_INVEST_VALIDATION:
- Independent? Negotiable? Valuable? Estimable? Small? Testable?
```

### Facilitar Retro
```
Roberto, facilite retrospective usando AVANADE_TASK_RETROSPECTIVE_FACILITATION:
- Sprint 15 dados: 20/22 pontos, 2 blockers, team mood 3.2/5
```

---

## 📚 Referências Rápidas

### Tasks
- **INVEST Validation**: `AVANADE_TASK_INVEST_VALIDATION`
- **Story Readiness**: `AVANADE_TASK_STORY_READINESS`
- **Retro Facilitation**: `AVANADE_TASK_RETROSPECTIVE_FACILITATION`

### Templates
- **Story YAML**: `AVANADE_STORY_TEMPLATE_YAML`
- **Story DoD**: `AVANADE_STORY_DOD_CHECKLIST_MD`
- **Create Next Story**: `AVANADE_CREATE_NEXT_STORY_TASK_MD`

### Workflows
- **Sprint Planning**: `AVANADE_WORKFLOW_GUIDE_SPRINT_PLANNING`

### Memória
- **SM Memory**: `AVANADE_MEMORY_SM_ROBERTO`

---

**Versão:** 2.0.0  
**Última Atualização:** Fevereiro 2026  
**Agente Anterior:** [05-paula-po.md](05-paula-po.md) | **Próximo:** [07-carla-qa.md](07-carla-qa.md)
