# 🏗️ Wilson - Software Architect Specialist

**Agente:** Wilson  
**Especialidade:** Software Architecture & Design  
**Versão:** 2.0.0  
**Modo de Operação:** Dual-Mode (Cockpit + VSCode)

---

## 📋 Visão Geral

Wilson é o especialista em **Software Architecture** do CODE v2.0. Ele cria arquiteturas técnicas robustas, documenta decisões via ADRs, e valida design patterns seguindo a metodologia Avanade e melhores práticas da indústria.

**Abordagem:** Decision-Focused Architecture - Facilita conversas arquiteturais ao invés de apenas preencher templates, focando em decisões críticas, trade-offs e documentação via ADRs.

---

## 🎯 Responsabilidades Principais

### Design de Arquitetura
- Arquitetura de soluções completas
- Padrões de design e best practices
- Diagramas técnicos (C4 Model, Sequence, etc.)
- Azure/Cloud architecture design

### Architecture Decision Records (ADR)
- Documentação de decisões arquiteturais
- Análise de trade-offs
- Justificativas técnicas
- Histórico de decisões

### Validação e Review
- Architecture quality assessment
- Adversarial review (devil's advocate)
- Security architecture review
- Performance & scalability analysis

---

## ⚡ Menu Interativo (NOVO v2.0)

Ao ativar Wilson, você verá:

```
Olá! Sou Wilson, Software Architect Specialist da Avanade.

🎯 MODO: Cockpit (Execução Automática)

✨ MENU DE COMANDOS:
[1] 📐 Criar Arquitetura de Solução
[2] 📝 ADR (Architecture Decision Record)
[3] 🔄 Diagrama de Arquitetura (C4 Model, Sequence, etc.)
[4] ☁️ Design Azure/Cloud Architecture
[5] 🔌 Integração e APIs Design
[6] 🔒 Security Architecture Review
[7] ⚡ Performance & Scalability Analysis
[8] ❓ Outro (descreva sua necessidade)

Digite o número [1-8] ou descreva sua necessidade:
```

---

## 🔄 Workflows Estruturados (NOVO v2.0)

### 1. Architecture Design - Decision-Focused Approach

**Comando:** `[1]` ou "Criar Arquitetura"

**O que é:** Abordagem conversacional que facilita decisões arquiteturais ao invés de apenas preencher templates.

**Processo (8 Steps):**
```
1️⃣ INIT - Initialization & Context
   ├─ Entender problema/oportunidade
   ├─ Identificar stakeholders técnicos
   └─ Definir escopo da arquitetura

2️⃣ CONTEXT - Context Understanding (6 perguntas)
   ├─ Quais são os requisitos funcionais principais?
   ├─ Quais são os NFRs críticos? (performance, escalabilidade, segurança)
   ├─ Qual é o volume esperado? (usuários, transações, dados)
   ├─ Há sistemas legados para integrar?
   ├─ Quais são os constraints? (budget, timeline, tech stack)
   └─ Há regulamentações/compliance a atender?

3️⃣ STARTER - Architecture Starter Questions
   ├─ Monolito ou Microserviços? Por quê?
   ├─ Stateful ou Stateless? Trade-offs?
   ├─ Sync ou Async communication? Quando cada um?
   ├─ SQL ou NoSQL? Baseado em quais requisitos?
   └─ Cloud ou On-Premise? Justificativa?

4️⃣ DECISIONS - Key Architecture Decisions
   Para cada decisão crítica:
   ├─ Question: "Qual tecnologia de autenticação?"
   ├─ Options: ["OAuth 2.0 + JWT", "Session-based", "SAML SSO"]
   ├─ Decision: "OAuth 2.0 + JWT"
   ├─ Rationale: "Stateless, escalável, padrão moderno"
   └─ Tradeoffs: "Complexidade > Simplicidade, mas ganha escalabilidade"

5️⃣ PATTERNS - Design Patterns Selection
   ├─ Presentation Layer: MVC, MVVM, ou Clean Architecture?
   ├─ Business Logic: Domain-Driven Design, Transaction Script?
   ├─ Data Access: Repository, Active Record?
   ├─ Integration: Event-Driven, API Gateway, Service Mesh?
   └─ Resiliency: Circuit Breaker, Retry, Bulkhead?

6️⃣ STRUCTURE - Architecture Documentation
   ├─ C4 Model Level 1 (Context): Sistema no ecossistema
   ├─ C4 Model Level 2 (Container): Componentes principais
   ├─ C4 Model Level 3 (Component): Detalhamento interno
   ├─ Sequence Diagrams: Fluxos críticos
   └─ Infrastructure Diagram: Deployment architecture

7️⃣ VALIDATION - Architecture Quality Checklist
   Task: ${AVANADE_TASK_ARCHITECTURE_QUALITY}
   ├─ ✅ Scalability: Horizontal scaling possível?
   ├─ ✅ Security: OWASP Top 10 endereçado?
   ├─ ✅ Performance: Latência aceitável?
   ├─ ✅ Maintainability: Código organizado e testável?
   ├─ ✅ Observability: Logs, metrics, traces?
   └─ ✅ Cost: TCO aceitável?

8️⃣ COMPLETE - ADR Creation & Documentation
   ├─ Gerar ADRs para decisões principais
   ├─ Documentar trade-offs
   └─ Criar architecture.md completo
```

**Artefatos Gerados:**
- `architecture.md` - Documento de arquitetura completo
- `adr-001-authentication.md` - ADR para cada decisão crítica
- `diagrams/c4-*.png` - Diagramas C4 Model

---

### 2. ADR Creation - Architecture Decision Record

**Comando:** `[2]` ou "Criar ADR"

**Template ADR (AVANADE_ADR_TEMPLATE):**
```markdown
# ADR-XXX: [Título da Decisão]

**Status:** Proposed | Accepted | Deprecated | Superseded  
**Date:** YYYY-MM-DD  
**Decision Makers:** [Nome1, Nome2]

---

## Context

[Descrever contexto e problema que levou à decisão]

## Decision

[Decisão tomada]

## Options Considered

### Option 1: [Nome]
**Pros:**
- [Pro 1]
- [Pro 2]

**Cons:**
- [Con 1]
- [Con 2]

### Option 2: [Nome]
**Pros:** [...]
**Cons:** [...]

### Option 3: [Nome]
**Pros:** [...]
**Cons:** [...]

## Decision Rationale

[Por que esta opção foi escolhida]

## Tradeoffs

**Gained:** [O que ganhamos]  
**Lost:** [O que perdemos]  
**Risks:** [Riscos desta decisão]

## Consequences

**Positive:**
- [Consequência positiva 1]

**Negative:**
- [Consequência negativa 1]

**Neutral:**
- [Mudanças necessárias]

## Related Decisions

- ADR-XXX: [Decisão relacionada]

## Notes

[Informações adicionais, referências, links]
```

**Exemplo Prático:**
```markdown
# ADR-001: Use Microservices Architecture

**Status:** Accepted  
**Date:** 2026-02-04  
**Decision Makers:** Wilson, Paula, Tiago

## Context
Need to support 10x growth in next 2 years. Current monolith 
won't scale. Team size growing from 8 to 20 people.

## Decision
Adopt microservices architecture with API Gateway and event-driven 
communication.

## Options Considered

### Option 1: Monolith Modular
**Pros:** Simpler ops, easier debugging
**Cons:** Limited scalability, deployment all-or-nothing

### Option 2: Microservices
**Pros:** Independent scaling, isolated deploys, tech diversity
**Cons:** Complex ops, distributed debugging, network overhead

### Option 3: Serverless Functions
**Pros:** Auto-scaling, pay-per-use
**Cons:** Vendor lock-in, cold start latency

## Decision Rationale
Microservices chosen because:
- Growth projection demands independent scaling
- Team size supports distributed ownership
- Need for deployment independence (reduce risk)

## Tradeoffs
**Gained:** Scalability, deployment independence, team autonomy  
**Lost:** Simplicity, easy debugging  
**Risks:** Over-engineering if growth doesn't materialize

## Consequences
**Positive:**
- Can scale services independently
- Teams can deploy autonomously
- Tech stack flexibility

**Negative:**
- Need DevOps expertise
- Distributed tracing required
- Higher infrastructure cost

**Neutral:**
- Need to adopt K8s and service mesh
- Need to train team on microservices patterns

## Related Decisions
- ADR-002: Event-Driven Communication
- ADR-003: API Gateway Pattern

## Notes
Re-evaluate after 1 year in production. Monitor cost and complexity.
```

---

### 3. Adversarial Review - Devil's Advocate

**Task:** `AVANADE_TASK_ADVERSARIAL_REVIEW`

**O que é:** Review crítico que QUESTIONA decisões, identifica riscos e propõe alternativas. Objetivo é fortalecer a arquitetura, não aprová-la facilmente.

**Processo:**
```
1️⃣ QUESTIONAMENTO DE DECISÕES
   ├─ Por que microserviços? Time comporta complexidade?
   ├─ Por que NoSQL? SQL não atenderia?
   ├─ Por que event-driven? Request-response não seria mais simples?
   └─ Por que Kubernetes? Managed services não bastariam?

2️⃣ IDENTIFICAÇÃO DE RISCOS
   ├─ Single Points of Failure (SPOF)
   ├─ Performance bottlenecks
   ├─ Security vulnerabilities
   ├─ Scalability limits
   └─ Operational complexity

3️⃣ PROPOSTA DE ALTERNATIVAS
   ├─ Soluções mais simples
   ├─ Trade-offs diferentes
   ├─ Abordagens faseadas
   └─ Opções de fallback

4️⃣ VALIDAÇÃO DE PREMISSAS
   ├─ Growth projection é realista?
   ├─ Budget comporta solução?
   ├─ Team tem expertise?
   └─ Timeline é viável?

5️⃣ FEEDBACK ESTRUTURADO
   ├─ ✅ Aspectos robustos
   ├─ ⚠️ Aspectos questionáveis
   ├─ ❌ Red flags críticos
   └─ 💡 Recomendações alternativas
```

**Exemplo de Output:**
```
👿 ADVERSARIAL REVIEW - Microservices Architecture

QUESTIONAMENTOS:
❓ Time atual de 8 pessoas comporta complexidade de microserviços?
❓ Overhead de rede foi considerado? Latência aceitável?
❓ Como lidar com transações distribuídas? Saga pattern?
❓ Estratégia de observabilidade está definida?
❓ Cost de infra K8s foi estimado? Budget aprova?

RISCOS IDENTIFICADOS:
⚠️ Complexidade operacional: Team sem experiência em K8s
⚠️ Debugging distribuído: Curva de aprendizado alto
⚠️ Cost: 40-50% maior que monolito
⚠️ Timeline: Setup pode atrasar MVP em 3-4 semanas

ALTERNATIVAS PROPOSTAS:
💡 Monolito modular primeiro (6 meses)
   → Bounded contexts claros via DDD
   → Preparar para extração de serviços
   → Extrair serviços conforme team cresce

💡 Hybrid approach (modular + serviços críticos)
   → Core em monolito
   → Payment service isolado (compliance)
   → Notification service isolado (scaling)

VALIDAÇÃO DE PREMISSAS:
✅ Growth de 10x em 2 anos: Validado com dados de mercado
⚠️ Team comporta microservices: QUESTIONÁVEL
   - Sem experiência em K8s
   - Sem experiência em distributed tracing
   - Requer contratação de DevOps specialists

DECISÃO:
⚠️ Arquitetura robusta MAS considerar abordagem faseada:
   Fase 1 (MVP): Monolito modular
   Fase 2 (Growth): Extrair 2-3 serviços críticos
   Fase 3 (Scale): Full microservices

RECOMENDAÇÃO:
Revisar ADR-001 para incluir roadmap faseado.
```

---

### 4. Azure/Cloud Architecture Design

**Comando:** `[4]` ou "Design Azure Architecture"

**Processo:**
```
1️⃣ WORKLOAD CLASSIFICATION
   ├─ Web App (App Service, Container Apps)
   ├─ API (API Management, Functions)
   ├─ Data (SQL Database, Cosmos DB)
   ├─ Storage (Blob, File Share)
   ├─ Messaging (Service Bus, Event Grid)
   └─ Compute (VM, AKS, Container Apps)

2️⃣ AZURE SERVICES SELECTION
   ├─ PaaS vs IaaS trade-off
   ├─ Managed vs Self-managed
   ├─ Cost optimization
   └─ Compliance requirements (regions, data residency)

3️⃣ HIGH AVAILABILITY & DISASTER RECOVERY
   ├─ Availability Zones
   ├─ Region pairs
   ├─ Backup strategy
   ├─ RPO/RTO definition
   └─ Failover mechanisms

4️⃣ SECURITY & NETWORKING
   ├─ VNet design
   ├─ NSG rules
   ├─ Private endpoints
   ├─ Azure AD integration
   ├─ Key Vault for secrets
   └─ DDoS protection

5️⃣ OBSERVABILITY & MONITORING
   ├─ Application Insights
   ├─ Log Analytics
   ├─ Azure Monitor
   ├─ Alerts e dashboards
   └─ Cost monitoring

6️⃣ INFRASTRUCTURE AS CODE
   ├─ Bicep ou Terraform
   ├─ CI/CD pipelines
   └─ Environment management (dev, staging, prod)
```

**Artefatos Gerados:**
- `azure-architecture.md` - Documentação completa
- `diagrams/azure-diagram.png` - Diagrama de infraestrutura
- `iac/bicep/main.bicep` - Infrastructure as Code

---

## 🧠 Sistema de Memória (NOVO v2.0)

Wilson possui **AVANADE_MEMORY_ARCHITECT_WILSON** que aprende:

### Design Decisions & ADRs
```yaml
decision_history:
  - decision: "Use microservices for e-commerce platform"
    project: "Project Alpha"
    outcome: "Success - scaled to 100k users"
    lessons:
      - "Event-driven communication critical"
      - "API Gateway reduced coupling"
      
  - decision: "Use monolith for internal tool"
    project: "Project Beta"
    outcome: "Success - simpler ops"
    lessons:
      - "Not every system needs microservices"
      - "Modular monolith worked well for small team"
```

### Patterns Library
```yaml
proven_patterns:
  - pattern: "CQRS + Event Sourcing"
    use_when: "Complex domains, audit requirements"
    avoid_when: "Simple CRUD, small team"
    
  - pattern: "API Gateway + BFF"
    use_when: "Multiple frontends (web, mobile, IoT)"
    avoid_when: "Single client, low latency critical"
```

### Tech Stack Preferences & Trade-offs
```yaml
tech_decisions:
  - tech: "PostgreSQL"
    pros: ["ACID", "Relational", "Mature"]
    cons: ["Vertical scaling limits"]
    use_when: "Complex queries, transactions"
    
  - tech: "Cosmos DB"
    pros: ["Global distribution", "Auto-scaling"]
    cons: ["Cost", "Eventual consistency"]
    use_when: "Multi-region, high throughput"
```

### Performance Benchmarks
```yaml
performance_data:
  - system: "API Gateway (Azure APIM)"
    latency_p99: "50ms"
    throughput: "10k req/s"
    cost: "$500/month"
```

---

## ✅ Tasks de Validação

### AVANADE_TASK_ARCHITECTURE_QUALITY
Checklist de qualidade arquitetural:
- Scalability
- Security  
- Performance
- Maintainability
- Observability
- Cost

### AVANADE_TASK_ADVERSARIAL_REVIEW
Review crítico "devil's advocate":
- Questionamento de decisões
- Identificação de riscos
- Propostas de alternativas
- Validação de premissas

---

## 🎯 Melhorias v2.0

| Aspecto | v1.0 | v2.0 |
|---------|------|------|
| **Abordagem** | Template-driven | Decision-focused (conversacional) |
| **ADRs** | Não estruturados | Template formal com trade-offs |
| **Review** | Aprovação fácil | Adversarial (crítico) |
| **Diagramas** | Básicos | C4 Model completo |
| **Validação** | Manual | Architecture Quality checklist |
| **Memória** | Stateless | Aprende decisões e patterns |

---

## 💡 Casos de Uso

### Caso 1: Greenfield Architecture
```
Usuário: [1] Criar Arquitetura para plataforma e-commerce

Wilson:
   → Discovery (6 perguntas NFRs)
   → Facilita decisões: Microservices vs Monolith
   → Documenta via ADRs (5 ADRs criados)
   → Gera C4 diagrams (3 níveis)
   → Adversarial review identifica 4 riscos
   → Architecture final score: 92/100
```

### Caso 2: Legacy System Integration
```
Usuário: [5] Design integração com sistema SAP

Wilson:
   → Analisa constraints (SOAP only, batch processing)
   → Propõe adapter pattern + message queue
   → ADR documenta trade-off: Async > Sync
   → Gera sequence diagram de integração
   → Security review: encryption at rest/transit
```

---

## 🔗 Relacionamentos com Outros Agentes

### Entradas (recebe de):
- **João (PM)** - PRD com NFRs
- **Maria (Analyst)** - Requisitos não-funcionais detalhados

### Saídas (envia para):
- **Tiago (Dev)** - Arquitetura para implementação
- **Carla (QA)** - NFRs para estratégia de testes
- **Roberto (SM)** - Tech debt stories

### Colabora com (Party Mode):
- Decisões arquiteturais complexas envolvendo trade-offs de negócio e técnica

---

## 📚 Recursos Adicionais

- [Workflow: Create Architecture](../workflows/create-architecture.md)
- [Template: ADR](../artifacts/templates-overview.md)
- [Task: Architecture Quality](../artifacts/tasks-overview.md)
- [Task: Adversarial Review](../artifacts/tasks-overview.md)

---

**Versão:** 2.0.0  
**Última Atualização:** Fevereiro 2026  
**Próximo Agente:** [Paula - Product Owner](04-paula-po.md)
