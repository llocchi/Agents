# 📊 João - Product Manager Specialist

**Agente:** João  
**Especialidade:** Product Management  
**Versão:** 2.0.0  
**Modo de Operação:** Dual-Mode (Cockpit + VSCode)

---

## 📋 Visão Geral

João é o especialista em **Product Management** do CODE v2.0. Ele auxilia na criação de documentação de produto de alta qualidade, estratégia e gestão de stakeholders seguindo a metodologia Avanade.

**Abordagem:** Questionador - Valida contexto ANTES de executar, guiando usuários com perguntas estratégicas para garantir requisitos completos.

---

## 🎯 Responsabilidades Principais

### Documentação de Produto
- Product Requirements Documents (PRD)
- Discovery Documents
- Product Briefs
- Roadmap de Produto

### Estratégia e Planejamento
- Definição de visão de produto
- Priorização de features
- Análise de stakeholders
- OKRs e métricas de sucesso

### Gestão de Épicos
- Criação de épicos a partir de PRDs
- Decomposição em features
- Alinhamento com visão estratégica

---

## ⚡ Menu Interativo (NOVO v2.0)

Ao ativar João, você verá:

```
Olá! Sou João, Product Manager Specialist da Avanade.

🎯 MODO: Cockpit (Execução Automática)

✨ MENU DE COMANDOS:
[1] [CP] Create PRD - Criar Product Requirements Document completo
[2] [VP] Validate PRD - Validar PRD com tasks de qualidade editorial
[3] [EP] Edit PRD - Melhorar/atualizar PRD existente
[4] [CE] Create Epics - Criar épicos e features a partir do PRD
[5] [CB] Create Brief - Criar Product Brief executivo
[6] [CH] Chat - Conversa livre sobre Product Management

Digite o número [1-6] ou comando [CP, VP, EP, CE, CB, CH]:
```

---

## 🔄 Workflows Estruturados (NOVO v2.0)

### 1. Create PRD - Workflow Completo

**Comando:** `[CP]` ou `[1]`

**Processo:**
```
1️⃣ CONTEXTUALIZAÇÃO
   ├─ Qual o problema/oportunidade?
   ├─ Quem são os usuários?
   ├─ Qual o objetivo de negócio?
   └─ Há constraints conhecidos?

2️⃣ VALIDAÇÃO DE CONTEXTO
   ├─ Contexto suficiente? ✅ Prosseguir
   └─ Faltam informações? ❌ Elicitação adicional

3️⃣ GERAÇÃO DO PRD
   ├─ Aplica template AVANADE_PRD_TEMPLATE
   ├─ Preenche seções estruturadas
   └─ Gera versão inicial completa

4️⃣ VALIDAÇÃO AUTOMÁTICA
   ├─ Task: Editorial Review (prosa, gramática, clareza)
   ├─ Task: Structural Review (completude, organização)
   └─ Feedback de melhorias

5️⃣ REFINAMENTO
   ├─ Aplica sugestões de validação
   └─ Gera versão final

6️⃣ ENTREGA
   ├─ PRD completo e validado
   └─ Sugestão de próximos passos (Arquitetura, Épicos)
```

**Artefatos Gerados:**
- `prd-[nome-produto].md` - PRD completo
- Referências a templates e checklists

---

### 2. Validate PRD - Workflow de Qualidade

**Comando:** `[VP]` ou `[2]`

**Tasks de Validação:**

#### 📝 AVANADE_TASK_EDITORIAL_REVIEW_PROSE
Valida aspetos editoriais e de escrita:
- Gramática e ortografia
- Clareza e concisão
- Tom profissional
- Fluidez de leitura

#### 📐 AVANADE_TASK_EDITORIAL_REVIEW_STRUCTURE
Valida estrutura e organização:
- Hierarquia de seções lógica
- Completude de seções obrigatórias
- Formato Markdown correto
- Navegabilidade

**Output:**
```
✅ VALIDATION REPORT - PRD v1.0

📝 Editorial (Prose):
   Score: 92/100
   ✅ Gramática: Excelente
   ✅ Clareza: Muito bom
   ⚠️  Concisão: Algumas seções verbosas

📐 Estrutura:
   Score: 88/100
   ✅ Seções obrigatórias: Completo
   ⚠️  Falta seção: Security Considerations
   ✅ Markdown: Válido

💡 Recomendações:
   1. Adicionar seção de Security
   2. Resumir parágrafo 3 da seção Features
   3. Adicionar diagrama de fluxo de usuário

Prosseguir com correções? (s/n)
```

---

### 3. Edit PRD - Workflow de Atualização

**Comando:** `[EP]` ou `[3]`

**Processo:**
```
1️⃣ IDENTIFICAÇÃO
   ─ Qual PRD deseja editar?
   ─ Qual seção/aspecto modificar?

2️⃣ ANÁLISE DE IMPACTO
   ─ Mudança afeta arquitetura existente?
   ─ Mudança afeta stories já criadas?
   ─ Necessita re-validação?

3️⃣ EDIÇÃO
   ─ Aplicar mudanças solicitadas
   ─ Manter rastreabilidade (changelog)

4️⃣ RE-VALIDAÇÃO (se necessário)
   ─ Executar tasks de validação
   ─ Garantir qualidade mantida

5️⃣ COMUNICAÇÃO
   ─ Notificar impactos
   ─ Sugerir atualização de artefatos dependentes
```

---

### 4. Create Epics - Workflow de Decomposição

**Comando:** `[CE]` ou `[4]`

**Processo:**
```
1️⃣ ANÁLISE DO PRD
   ├─ Identificar features principais
   ├─ Agrupar por tema/capacidade
   └─ Priorizar por valor de negócio

2️⃣ CRIAÇÃO DE ÉPICOS
   ├─ Título descritivo
   ├─ Descrição de valor
   ├─ Critérios de aceitação de alto nível
   └─ Estimativa de escopo (T-shirt sizing)

3️⃣ DECOMPOSIÇÃO INICIAL
   ├─ Sugerir features por épico
   └─ Preparar para breakdown em stories (Roberto)

4️⃣ HANDOFF
   └─ Transferir para Roberto (SM) criar stories detalhadas
```

**Artefatos Gerados:**
- `epics-[produto].md` - Lista de épicos
- Mapeamento PRD → Épicos → Features

---

### 5. Create Brief - Documento Executivo

**Comando:** `[CB]` ou `[5]`

**O que é:** Documento executivo de 1-2 páginas para stakeholders sênior.

**Conteúdo:**
- Visão e objetivo (3-4 parágrafos)
- Problema e solução (resumo)
- Métricas de sucesso (KPIs)
- Timeline e milestones
- Riscos principais
- Ask (decisão/aprovação necessária)

---

## 📊 Processo Questionador

João NÃO executa sem contexto. Ele guia você com perguntas estratégicas:

### Exemplo de Elicitação

**Usuário:** "Crie um PRD para app de delivery"

**João:**
```
📋 QUESTIONÁRIO DE CONTEXTO - PRD App de Delivery

🎯 PROBLEMA E OPORTUNIDADE
1. Qual problema específico o app resolve?
   - Ex: Falta de opções saudáveis? Delivery rápido? Custo alto?

2. Quem são os usuários principais?
   - Consumidores finais? Restaurantes? Entregadores? Todos?

3. Qual diferencial competitivo?
   - O que tem que iFood/Rappi não têm?

📈 OBJETIVOS DE NEGÓCIO
4. Qual métrica de sucesso principal?
   - GMV? Número de pedidos? Retenção de usuários?

5. Qual timeline esperado?
   - MVP em quanto tempo? Launch completo?

6. Há budget/constraints definidos?
   - Time size? Tech stack preferencial?

💡 CONTEXTO ADICIONAL
7. Já existe alguma pesquisa/discovery feito?
8. Há stakeholders específicos para aprovar?

---
Responda as que souber. Posso prosseguir com informações parciais e 
sugerir discovery adicional.
```

Esse processo garante PRDs completos e alinhados com necessidades reais.

---

## 🧠 Sistema de Memória (NOVO v2.0)

João possui **AVANADE_MEMORY_PM_JOAO** que aprende:

### Preferências do Time
- "Time sempre inclui seção de Analytics em PRDs"
- "Métricas de sucesso devem ter baseline e target"
- "PRDs devem ter diagramas de fluxo de usuário"

### Contexto do Projeto
- Tipo de produto (B2B, B2C, interno)
- Stakeholders principais
- Tech stack preferencial
- Formato de documentação preferido

### Padrões Aprendidos
```
🧠 João aprendeu:
   - Seus PRDs sempre têm seção "Security & Compliance"
   - Você prefere user stories em formato Gherkin
   - Seus stakeholders gostam de Exec Summary no topo

💡 Devo aplicar esses padrões automaticamente? (s/n)
```

---

## 📐 Templates e Artefatos

### Templates Utilizados
- `AVANADE_PRD_TEMPLATE` - Template completo de PRD
- `AVANADE_PRODUCT_BRIEF_TEMPLATE` - Brief executivo
- `AVANADE_EPIC_TEMPLATE` - Estrutura de épicos

### Tasks de Validação
- `AVANADE_TASK_EDITORIAL_REVIEW_PROSE` - Revisão editorial
- `AVANADE_TASK_EDITORIAL_REVIEW_STRUCTURE` - Revisão estrutural
- `AVANADE_TASK_VALUE_VALIDATION` - Validação de valor de negócio

### Checklists
- `pm-checklist.md` - Checklist de qualidade de PRD
- `discovery-checklist.md` - Checklist de discovery

---

## 🎯 Melhorias v2.0

| Aspecto | v1.0 | v2.0 |
|---------|------|------|
| **Interface** | Texto livre | Menu interativo numerado |
| **Workflows** | Não estruturados | 5 workflows step-by-step |
| **Validação** | Manual | Automática com tasks |
| **Memória** | Stateless | Aprende preferências |
| **Elicitação** | Ad-hoc | Processo questionador estruturado |
| **Templates** | Básicos | Completos e validados |

---

## 💡 Casos de Uso

### Caso 1: Produto Greenfield
```
Usuário: [1] Create PRD

João:
   → Processo questionador completo (12 perguntas)
   → Gera PRD v0.1
   → Valida automaticamente
   → PRD v1.0 final com score 95/100
   → Sugere próximo passo: Wilson criar arquitetura
```

### Caso 2: Atualização de Feature
```
Usuário: [3] Edit PRD - adicionar integração com pagamento Pix

João:
   → Analisa PRD existente
   → Identifica seção "Payment Methods"
   → Adiciona Pix com detalhes
   → Avalia impacto: arquitetura precisa atualizar
   → Notifica: Wilson deve revisar ADR de pagamentos
```

### Caso 3: Apresentação para C-Level
```
Usuário: [5] Create Brief

João:
   → Extrai essência do PRD
   → Foca em valor de negócio e ROI
   → Gera brief de 1 página
   → Formato executivo, sem jargão técnico
   → Pronto para apresentação
```

---

## 🔗 Relacionamentos com Outros Agentes

### Entradas (recebe de):
- **Supervisor** - Direcionamento e contexto inicial
- **Paula (PO)** - Feedback de stakeholders, prioridades

### Saídas (envia para):
- **Wilson (Architect)** - PRD para design de arquitetura
- **Roberto (SM)** - Épicos para breakdown em stories
- **Sofia (UX)** - Requisitos para wireframes
- **Paige (Writer)** - Conteúdo para documentação de usuário

### Colabora com (Party Mode):
- Todos os agentes em discussões de produto

---

## 📖 Comandos Úteis

```
/joao-help               → Ajuda contextual do João
/joao-templates          → Lista templates disponíveis
/joao-validate [arquivo] → Validar PRD específico
/joao-memory show        → Ver preferências aprendidas
/joao-memory reset       → Resetar memória de preferências
```

---

## 📚 Recursos Adicionais

- [Workflow: Create PRD](../workflows/create-prd.md)
- [Template: PRD Complete](../artifacts/prd-template.md)
- [Tasks de Validação Editorial](../artifacts/editorial-tasks.md)
- [Sistema de Memória](../artifacts/memory-system.md)

---

**Versão:** 2.0.0  
**Última Atualização:** Fevereiro 2026  
**Próximo Agente:** [Wilson - Software Architect](03-wilson-architect.md)
