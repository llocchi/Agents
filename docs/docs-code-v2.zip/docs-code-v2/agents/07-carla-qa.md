# 07. Carla - QA Specialist ✅

**Versão:** 2.0.0  
**Agent ID:** `AVANADE_QA_CARLA`  
**Especialidade:** Quality Assurance & Testing

---

## 📋 Visão Geral

Carla é a QA Specialist do CODE v2.0, responsável por:
- **Code Review Adversarial**: Encontra 3-10 issues SEMPRE (abordagem crítica)
- **Test Planning**: Estratégia completa (Unit, Integration, E2E)
- **Quality Gates**: Validação de DoD antes de produção
- **Test Coverage Analysis**: Garantir >80% coverage
- **Bug Analysis & Root Cause**: Deep dive em defeitos

### Menu Interativo (8 Opções)

```
✅ QUALITY ASSURANCE
1. 🔍 Code Review
2. 📋 Criar Test Plan
3. 🧪 Definir Test Cases
4. 🚦 Quality Gate Validation
5. 🔧 Refactoring Suggestions
6. 📊 Coverage Analysis
7. 🐛 Bug Analysis & Root Cause
8. ❓ Outro (descreva sua necessidade)
```

---

## 🔄 Workflows Principais

### 1. 🔍 Workflow: Adversarial Code Review

**Quando usar**: Revisar código antes de merge (PR review)

**Artifact**: `AVANADE_TASK_CODE_REVIEW`

**Abordagem Adversarial**: Carla SEMPRE encontra 3-10 issues. Não é code review "light" - é crítico e rigoroso.

**Processo (7 Passos)**:

#### Passo 1: Checklist Avanade
```markdown
## Code Quality Checklist

### Clean Code
- [ ] Nomes de variáveis/funções são claros e descritivos?
- [ ] Funções têm <20 linhas? (Se >20, precisa refatorar)
- [ ] Sem código comentado (dead code)?
- [ ] Sem magic numbers (usar constantes nomeadas)?

### SOLID Principles
- [ ] Single Responsibility: Cada classe tem 1 responsabilidade?
- [ ] Open/Closed: Extensível sem modificar?
- [ ] Dependency Injection: Dependencies injetadas, não hardcoded?

### DRY (Don't Repeat Yourself)
- [ ] Sem código duplicado? (DRY violation?)
- [ ] Lógica comum extraída para funções/helpers?
```

#### Passo 2: Security Review
```markdown
## Security Checklist

### Input Validation
- [ ] Todos inputs do usuário são validados?
- [ ] Sanitização contra SQL injection?
- [ ] Sanitização contra XSS?
- [ ] Validação de file uploads (tipo, tamanho)?

### Authentication & Authorization
- [ ] Endpoints protegidos com auth?
- [ ] Role-based access control (RBAC) implementado?
- [ ] Tokens/sessions expiram adequadamente?

### Sensitive Data
- [ ] Senhas hasheadas (bcrypt/argon2)?
- [ ] Secrets não estão hardcoded?
- [ ] Dados sensíveis não logados?
```

#### Passo 3: Performance Review
```markdown
## Performance Checklist

### Database
- [ ] Sem N+1 queries? (usar joins/eager loading)
- [ ] Indexes apropriados nas queries?
- [ ] Paginação implementada para listas grandes?

### Code
- [ ] Sem loops desnecessários? (O(n²) evitado)
- [ ] Caching implementado onde apropriado?
- [ ] Lazy loading para recursos pesados?

### Memory
- [ ] Sem memory leaks? (listeners removidos, connections fechadas)
- [ ] Large objects liberados após uso?
```

#### Passo 4: Test Review
```markdown
## Test Coverage Checklist

### Unit Tests
- [ ] Coverage >80% para código novo?
- [ ] Testes cobrem happy path + edge cases?
- [ ] Mocks apropriados (não testa implementação de dependências)?

### Integration Tests
- [ ] Testes de integração para fluxos críticos?
- [ ] APIs testadas com diferentes inputs?

### Edge Cases
- [ ] Null/undefined testados?
- [ ] Empty strings/arrays testados?
- [ ] Boundary values testados? (0, -1, MAX_INT)
```

#### Passo 5: Documentation Review
```markdown
## Documentation Checklist

- [ ] README atualizado com mudanças?
- [ ] Comments explicam "por quê", não "o quê"?
- [ ] API docs geradas (se API pública)?
- [ ] Commit messages descritivos?
```

#### Passo 6: Feedback Construtivo
Carla oferece feedback em **3 níveis de severidade**:

```markdown
🔴 CRÍTICO (Blocker - não pode mergear)
- Security vulnerability
- Breaking change não documentado
- Tests falhando
- Performance degradation >50%

🟡 IMPORTANTE (Deve corrigir antes de merge)
- Code quality issues (SOLID violations)
- Falta de tests para edge cases
- Performance issue moderado
- Documentation incompleta

🔵 SUGESTÃO (Nice to have, pode mergear)
- Refactoring oportunidade
- Melhoria de legibilidade
- Optimization não crítica
```

**Exemplo de Review Output**:
```
## Code Review - PR #234

### 🔴 CRÍTICO (2)
1. **SQL Injection Vulnerability** [Line 45]
   - Input `userId` não está sendo sanitizado
   - Fix: Usar prepared statement ou ORM query builder
   
2. **Tests Failing** [CI/CD]
   - 3 unit tests falhando após mudanças
   - Fix: Atualizar tests ou código

### 🟡 IMPORTANTE (4)
3. **N+1 Query Problem** [Line 78]
   - Loop fazendo query individual para cada user
   - Fix: Usar `.include()` ou JOIN query
   
4. **Missing Edge Case Tests** [tests/user.test.js]
   - Não testa cenário de email duplicado
   - Fix: Adicionar test case para duplicate email
   
5. **Magic Number** [Line 102]
   - Hardcoded `86400` (não é óbvio que são seconds in day)
   - Fix: Const `SECONDS_IN_DAY = 86400`
   
6. **Error Handling Missing** [Line 120]
   - API call sem try/catch
   - Fix: Adicionar error handling + user-friendly message

### 🔵 SUGESTÃO (3)
7. **Function Too Long** [Line 200-250]
   - Função `processOrder()` com 50 linhas
   - Sugestão: Extrair em funções menores (validateOrder, calculateTotal, etc.)
   
8. **Variable Naming** [Line 88]
   - `const d = new Date()` - nome não descritivo
   - Sugestão: `const createdAt = new Date()`
   
9. **Duplicated Logic** [Line 150, 180]
   - Mesma validação de email em 2 lugares
   - Sugestão: Extrair para helper `validateEmail()`

---

**Decisão**: ❌ REQUEST CHANGES (2 críticos devem ser corrigidos)

**Auto-Fix Option**: Carla pode corrigir automaticamente issues 5, 8, 9?
```

#### Passo 7: Auto-Fix Option
Após review, Carla oferece corrigir automaticamente issues simples:
- Magic numbers → constants
- Variable naming → descriptive names
- Duplicated code → extract to function
- Missing null checks → add validation

---

### 2. 📋 Workflow: Test Planning

**Quando usar**: Criar estratégia de testes para feature/sprint

**Artifact**: `AVANADE_TEST_PLAN_TEMPLATE`

**Processo (7 Passos)**:

#### Passo 1: Discovery Protocol (6 Perguntas de QA)
1. Qual é o escopo da feature? (Frontend? Backend? Full-stack?)
2. Quais são os riscos principais? (Segurança? Performance? UX?)
3. Qual coverage target? (80%? 90%? 100% para código crítico?)
4. Quais test types necessários? (Unit, Integration, E2E, Load, Security?)
5. Qual test data necessária? (Mock? Seed database? Production-like?)
6. Quais ambientes de teste? (Local? Staging? Pre-prod?)

#### Passo 2: Scope Definition
```yaml
test_scope:
  feature: "Product Filter Feature"
  components:
    frontend:
      - Filter UI component
      - Filter state management
      - API integration layer
    
    backend:
      - /api/products/filter endpoint
      - Filter query builder
      - Database indexes
    
    integration:
      - Frontend ↔ Backend communication
      - Database query performance
```

#### Passo 3: Test Types
```yaml
test_strategy:
  unit_tests:
    target_coverage: 85%
    components:
      - Filter logic (frontend)
      - Query builder (backend)
      - Validation functions
    tools: [Jest, React Testing Library]
  
  integration_tests:
    scenarios:
      - API endpoint com diferentes filtros
      - Database query performance
      - Error handling (network failure, timeout)
    tools: [Supertest, Postman]
  
  e2e_tests:
    user_flows:
      - User seleciona filtro → vê resultados filtrados
      - User combina múltiplos filtros
      - User limpa filtros
    tools: [Cypress, Playwright]
  
  performance_tests:
    scenarios:
      - 100 concurrent users filtering
      - Database query com 10k+ products
    tools: [k6, Artillery]
    
  security_tests:
    focus:
      - SQL injection no filter input
      - XSS em filter parameters
    tools: [OWASP ZAP, Burp Suite]
```

#### Passo 4: Test Cases
**Formato**: Given/When/Then

```yaml
test_cases:
  - id: TC-001
    title: "Filter por categoria única"
    priority: High
    type: E2E
    steps:
      given: "Usuário está na página de produtos"
      when: "Seleciona filtro 'Eletrônicos'"
      then: "Vê apenas produtos de Eletrônicos"
      and: "Contador mostra quantidade correta"
    
    expected_result: "Produtos filtrados + contador"
    test_data: "Database com 100 produtos (30 Eletrônicos)"
  
  - id: TC-002
    title: "Múltiplos filtros combinados"
    priority: High
    type: E2E
    steps:
      given: "Usuário está na página de produtos"
      when: "Seleciona 'Eletrônicos' E 'Faixa de preço: R$100-R$500'"
      then: "Vê produtos que atendem AMBOS critérios"
    
    expected_result: "Produtos filtrados (AND logic)"
    test_data: "50 produtos Eletrônicos, 20 na faixa R$100-R$500"
  
  - id: TC-003
    title: "Edge case - Nenhum produto encontrado"
    priority: Medium
    type: E2E
    steps:
      given: "Usuário está na página de produtos"
      when: "Seleciona filtros que não retornam resultados"
      then: "Vê mensagem 'Nenhum produto encontrado'"
      and: "Opção para limpar filtros é exibida"
    
    expected_result: "Empty state + clear filters option"
  
  - id: TC-004
    title: "Performance - 10k produtos"
    priority: High
    type: Performance
    steps:
      given: "Database com 10.000 produtos"
      when: "Usuário aplica filtro"
      then: "Resposta em <500ms"
    
    expected_result: "Response time <500ms"
    test_data: "Seed 10k produtos"
  
  - id: TC-005
    title: "Security - SQL Injection"
    priority: Critical
    type: Security
    steps:
      given: "Filter endpoint"
      when: "Envia payload: category=' OR 1=1--"
      then: "Payload é sanitizado, retorna 400 Bad Request"
    
    expected_result: "No SQL injection vulnerability"
```

#### Passo 5: Test Data
```yaml
test_data:
  local_dev:
    - Seed script: seeds/products-100.js (100 produtos)
    - Categories: Eletrônicos, Roupas, Livros, Casa
    - Price range: R$10 - R$10.000
  
  staging:
    - Production-like data (anonymized)
    - 5.000 produtos
    - User accounts: test-user-1 a test-user-10
  
  mock_data:
    - API mocks para integration tests
    - Fixtures: fixtures/products.json
```

#### Passo 6: Execution Plan
```yaml
execution:
  phase_1_unit:
    duration: "Week 1"
    owner: Dev team
    exit_criteria: ">85% coverage, all tests green"
  
  phase_2_integration:
    duration: "Week 2"
    owner: QA + Dev
    exit_criteria: "All API scenarios pass"
  
  phase_3_e2e:
    duration: "Week 2"
    owner: QA
    exit_criteria: "All user flows pass in staging"
  
  phase_4_performance:
    duration: "Week 2"
    owner: QA + DevOps
    exit_criteria: "<500ms response, <2% error rate"
  
  phase_5_security:
    duration: "Week 3"
    owner: Security + QA
    exit_criteria: "No critical vulnerabilities"
```

#### Passo 7: Exit Criteria (Quality Gates)
```yaml
quality_gates:
  functional:
    - "100% dos critical test cases passaram"
    - "95% dos high priority test cases passaram"
  
  coverage:
    - "Unit test coverage >85%"
    - "Integration tests cobrem top 10 user flows"
  
  performance:
    - "Response time <500ms (p95)"
    - "Error rate <1% em load test"
  
  security:
    - "Zero critical vulnerabilities"
    - "Zero high-severity vulnerabilities"
  
  documentation:
    - "Test cases documentados"
    - "Known issues trackados"
```

**Output**: Test plan completo, ready para execução.

---

## ✅ Tasks de Validação

### 📋 Test Coverage Validation
**Artifact**: `AVANADE_TASK_TEST_COVERAGE`

```markdown
## Coverage Metrics

### Unit Tests: >80%
- [ ] Lógica de negócio (business logic) >90%
- [ ] Utilities/helpers >85%
- [ ] UI components >80%
- [ ] Edge cases cobertos (null, empty, boundary values)

### Integration Tests
- [ ] API endpoints críticos testados
- [ ] Database operations testadas
- [ ] Third-party integrations testadas (com mocks)

### E2E Tests
- [ ] Top 10 user flows cobertos
- [ ] Happy path + error paths
- [ ] Cross-browser (Chrome, Firefox, Safari)

### Performance Tests
- [ ] Load test (100+ concurrent users)
- [ ] Stress test (identificar breaking point)
- [ ] Database query performance (<200ms)

### Security Tests
- [ ] SQL injection testado
- [ ] XSS testado
- [ ] Authentication/Authorization testado
- [ ] OWASP Top 10 verificado
```

---

### 🔍 Boundary Value Analysis
**Artifact**: `AVANADE_TASK_BOUNDARY_VALUE_ANALYSIS`

**Quando usar**: Definir test cases para inputs numéricos/limites

**Exemplo**: Input de "Idade" aceita 0-120

```yaml
boundary_tests:
  - input: -1        # Invalid (abaixo do limite)
    expected: Error "Idade deve ser >= 0"
  
  - input: 0         # Boundary (limite inferior)
    expected: Aceito
  
  - input: 1         # Valid (logo acima do limite)
    expected: Aceito
  
  - input: 60        # Valid (meio do range)
    expected: Aceito
  
  - input: 119       # Valid (logo abaixo do limite)
    expected: Aceito
  
  - input: 120       # Boundary (limite superior)
    expected: Aceito
  
  - input: 121       # Invalid (acima do limite)
    expected: Error "Idade deve ser <= 120"
```

---

## 🧠 Sistema de Memória

### Arquivo: `AVANADE_MEMORY_QA_CARLA`

```yaml
defect_patterns:
  - pattern: "SQL Injection em filter endpoints"
    occurrences: 3
    root_cause: "Devs não usando prepared statements"
    solution: "Adicionar linter rule + training session"
  
  - pattern: "N+1 queries em list endpoints"
    occurrences: 5
    root_cause: "Falta de eager loading"
    solution: "Code review checklist + ORM best practices doc"

test_data_library:
  - name: "E-commerce 100 products"
    file: seeds/products-100.js
    use_cases: ["Filter tests", "Search tests", "Pagination"]
  
  - name: "User accounts (test users)"
    file: seeds/users-test.js
    credentials: "test-user-{1-10} / Password123!"

quality_metrics:
  sprint_15:
    bugs_found: 12
    critical: 2
    high: 4
    medium: 6
    bug_escape_rate: 8%  # bugs found in prod
    avg_fix_time: "4 hours"
  
  trends:
    - "Bug count reduzindo (15 → 12 → 10 últimas 3 sprints)"
    - "Escape rate melhorando (15% → 8%)"

testing_learnings:
  - learning: "Performance tests devem rodar ANTES de sprint review"
    context: "Sprint 14 - performance issue encontrado em review"
  
  - learning: "Mock external APIs em integration tests"
    context: "External API instability causou tests flaky"
```

---

## 📖 Casos de Uso

### Caso de Uso 1: Code Review Rigoroso

**Contexto**: PR com 500 linhas de código para "Product Filter Feature".

**Solução**:
1. User: **1** (Code Review)
2. Carla aplica **7-step review process**
3. Encontra **9 issues**:
   - 1 SQL injection (🔴 Crítico)
   - 1 N+1 query (🟡 Importante)
   - 3 missing tests (🟡 Importante)
   - 4 code quality (🔵 Sugestão)
4. Decisão: **❌ Request Changes**
5. Oferece **auto-fix** para 4 code quality issues

**Output**: PR bloqueado até críticos serem corrigidos.

---

### Caso de Uso 2: Test Plan para Feature Complexa

**Contexto**: "Real-time Chat Feature" - Alto risco (concurrency, performance, security).

**Solução**:
1. User: **2** (Criar Test Plan)
2. Carla faz **Discovery** (6 perguntas)
3. Define **scope**:
   - Unit: Chat message validation, WebSocket handlers
   - Integration: WebSocket connection, message persistence
   - E2E: User sends message → recipient receives
   - Performance: 1000 concurrent connections
   - Security: XSS em messages, auth validation
4. Cria **35 test cases** (15 unit, 10 integration, 5 E2E, 3 performance, 2 security)
5. Define **quality gates**: <200ms latency, zero message loss

**Output**: Comprehensive test plan preventing major issues.

---

## 💡 Comandos Úteis

```
Carla, faça code review de PR #234 usando AVANADE_TASK_CODE_REVIEW

Carla, crie test plan para feature "User Authentication" usando AVANADE_TEST_PLAN_TEMPLATE

Carla, analise boundary values para input "Age" (0-120) usando AVANADE_TASK_BOUNDARY_VALUE_ANALYSIS

Carla, consulte AVANADE_MEMORY_QA_CARLA: Quais defect patterns são recorrentes?
```

---

## 📚 Referências

- **Code Review**: `AVANADE_TASK_CODE_REVIEW`
- **Test Coverage**: `AVANADE_TASK_TEST_COVERAGE`
- **Boundary Analysis**: `AVANADE_TASK_BOUNDARY_VALUE_ANALYSIS`
- **Test Plan Template**: `AVANADE_TEST_PLAN_TEMPLATE`
- **DoD Checklist**: `AVANADE_STORY_DOD_CHECKLIST_MD`
- **Memória**: `AVANADE_MEMORY_QA_CARLA`

---

**Versão:** 2.0.0  
**Última Atualização:** Fevereiro 2026  
**Agente Anterior:** [06-roberto-sm.md](06-roberto-sm.md) | **Próximo:** [08-tiago-dev.md](08-tiago-dev.md)
