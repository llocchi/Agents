# 🔄 Guia de Migração v1.0 → v2.0

**Versão:** 2.0.0  
**Audiência:** Times usando CODE v1.0  
**Tempo Estimado:** 2-4 horas para migração completa

---

## 📋 Visão Geral da Migração

Esta guia orienta a transição do **CODE v1.0** para o **CODE v2.0**, detalhando mudanças, passos de migração e considerações importantes.

---

## 🎯 Resumo das Mudanças Principais

### O que mudou?

| Aspecto | v1.0 | v2.0 | Impacto |
|---------|------|------|---------|
| **Interface** | Texto livre | Menu interativo | 🟢 Melhoria UX |
| **Workflows** | Não estruturados | 18 workflows formais | 🟢 Processos claros |
| **Validação** | Manual | Automática (14 tasks) | 🟢 Qualidade garantida |
| **Memória** | Stateless | Persistente | 🟢 Personalização |
| **Colaboração** | Agentes isolados | Party Mode | 🟢 Brainstorming multi-agente |
| **Navegação** | Sem orientação | `/avanade-help` contextual | 🟢 Rastreabilidade |

---

## ⚠️ Breaking Changes

### 1. Formato de Ativação de Agentes

**v1.0:**
```
"João, crie um PRD para app de delivery"
```

**v2.0:**
```
#avanade-method
> João
[1] Create PRD
> "app de delivery"
```

**Ação Necessária:** Familiarizar-se com novo menu interativo. Processo é guiado passo a passo.

---

### 2. Estrutura de Artefatos

**v1.0:**
```
prd.md (formato livre)
```

**v2.0:**
```
prd.md (baseado em AVANADE_PRD_TEMPLATE)
+ validação automática
+ score de qualidade
+ changelog integrado
```

**Ação Necessária:** 
- ✅ Artefatos v1.0 continuam funcionando
- 💡 Recomenda-se re-validar com tasks v2.0 para garantir qualidade

---

### 3. Workflows Explícitos

**v1.0:** Processo implícito, cada execução diferente

**v2.0:** Workflows formalizados e consistentes

**Ação Necessária:** Aprender novos workflows (documentação disponível)

---

### 4. Sistema de Memória

**v1.0:** Sem memória, sempre stateless

**v2.0:** Memória persistente por agente

**Ação Necessária:**
- 🟢 Não é necessário migrar nada
- 💡 Sistema aprende automaticamente ao longo do uso
- ⚙️ Pode configurar preferências manualmente se desejar acelerar

---

## 🚀 Processo de Migração

### Fase 1: Preparação (30 min)

#### 1.1. Backup de Artefatos Existentes
```bash
# Criar backup de todos artefatos v1.0
mkdir -p backup-v1.0
cp -r .avanade-method/ backup-v1.0/
cp -r .github/chatmodes/ backup-v1.0/
cp -r .copilot/ backup-v1.0/
```

#### 1.2. Inventário de Artefatos
Listar todos os artefatos criados em v1.0:
- [ ] PRDs
- [ ] Arquiteturas
- [ ] User Stories
- [ ] Test Plans
- [ ] Documentações

#### 1.3. Leitura de Documentação v2.0
- [ ] Ler [README Principal](../README.md)
- [ ] Ler [Documentação de Agentes](../agents/)
- [ ] Ler [Sistema de Artefatos](../artifacts/system-overview.md)

---

### Fase 2: Atualização da Plataforma (1 hora)

#### 2.1. Atualizar Cockpit / MCP Server

**Se usando Cockpit:**
```bash
# Atualizar configuração MCP
# Verificar com admin da plataforma
```

**Se usando Local MCP:**
```bash
# Atualizar package
npm update @avanade/method-mcp-server
```

#### 2.2. Verificar Agentes Atualizados
```
#avanade-method
> Supervisor

Esperado: Menu v2.0 com opções:
[1] Analyze Project
[2] Create Artifact  
[3] Validate Artifact
[4] Party Mode
[5] Deploy Environment
[6] Help
```

Se menu não aparecer → Atualização não completa

---

### Fase 3: Migração de Artefatos (1-2 horas)

#### 3.1. Re-validar PRDs Existentes

**Para cada PRD v1.0:**
```
#avanade-method
> João
[2] Validate PRD
> path/to/prd-v1.0.md
```

**João irá:**
1. Analisar estrutura atual
2. Executar tasks de validação v2.0
3. Gerar relatório de qualidade
4. Sugerir melhorias

**Exemplo de Output:**
```
✅ VALIDATION REPORT - prd-app-delivery.md

📝 Editorial (Prose): 85/100
   ⚠️  Seção "Overview" muito verbosa
   ⚠️  Falta clareza em "Success Metrics"

📐 Estrutura: 78/100
   ❌ Falta seção: "Security Considerations"
   ❌ Falta seção: "Analytics & Tracking"
   ✅ Markdown válido

💡 Sugestões:
   1. Adicionar seções obrigatórias
   2. Simplificar Overview (max 3 parágrafos)
   3. Definir métricas com baseline/target

Deseja que eu corrija automaticamente? (s/n)
```

**Decisão:**
- **s** → João atualiza PRD para v2.0
- **n** → Mantém como está (v1.0 continua funcional)

---

#### 3.2. Re-validar Arquiteturas

**Para cada arquitetura v1.0:**
```
#avanade-method
> Wilson
[3] Validate Architecture
> path/to/architecture.md
```

**Wilson irá:**
1. Verificar se há ADRs documentados
2. Executar task ADVERSARIAL_REVIEW
3. Validar NFRs (non-functional requirements)
4. Sugerir melhorias

---

#### 3.3. Re-validar User Stories

**Para backlog de stories v1.0:**
```
#avanade-method
> Roberto
[3] Validate Stories
> path/to/backlog.md
```

**Roberto irá:**
1. Executar task INVEST_VALIDATION
2. Executar task STORY_READINESS
3. Identificar stories não prontas para sprint
4. Sugerir refinamentos

---

### Fase 4: Configuração de Preferências (30 min)

#### 4.1. Definir Preferências de Time

**Opção 1: Deixar Aprender Automaticamente**
```
# Não fazer nada
# Sistema aprende ao longo do uso
```

**Opção 2: Configurar Manualmente**
```
#avanade-method
> Supervisor
[6] Configure Memory

Preferências de Time:
- Tipo de projeto: [B2C Mobile App]
- Tech stack: [React Native, Node.js, PostgreSQL]
- Sempre incluir seções: [Security, Analytics, Observability]
- Formato de métricas: [baseline + target + tracking]
- Estilo de docs: [informal mas profissional]

Salvar? (s/n)
```

#### 4.2. Configurar Stakeholders

```
#avanade-method
> João
[6] Configure Stakeholders

Stakeholder 1:
- Nome: Maria Silva
- Cargo: Product Director
- Comunicação preferida: Monthly reports, Exec Brief format

Stakeholder 2:
- Nome: Carlos Tech
- Cargo: CTO
- Comunicação preferida: ADRs, technical deep-dives

Salvar? (s/n)
```

---

### Fase 5: Treinamento de Time (1 hora)

#### 5.1. Workshop Interno

**Agenda Sugerida:**
1. **Visão Geral v2.0** (15 min)
   - Principais melhorias
   - Menu interativo
   - Workflows estruturados

2. **Demo Prática** (30 min)
   - Criar PRD v2.0
   - Validar artefato existente
   - Usar Party Mode

3. **Q&A** (15 min)
   - Dúvidas do time
   - Casos de uso específicos

#### 5.2. Material de Referência

Disponibilizar para o time:
- [ ] [README v2.0](../README.md)
- [ ] [Quick Start Guide](quick-start.md)
- [ ] [Cheat Sheet de Comandos](cheat-sheet.md)

---

## 📊 Checklist de Migração

### Pré-Migração
- [ ] Backup completo de artefatos v1.0
- [ ] Inventário de PRDs, arquiteturas, stories
- [ ] Leitura de documentação v2.0
- [ ] Definição de janela de migração (2-4h sem prod)

### Migração
- [ ] Atualizar plataforma (Cockpit/MCP)
- [ ] Verificar menu v2.0 funcionando
- [ ] Re-validar PRDs existentes
- [ ] Re-validar arquiteturas
- [ ] Re-validar user stories
- [ ] Configurar preferências de time

### Pós-Migração
- [ ] Treinamento de time
- [ ] Workshop de 1h
- [ ] Disponibilizar material de referência
- [ ] Monitorar primeiros usos
- [ ] Coletar feedback

---

## 🎯 Estratégias de Migração

### Estratégia 1: Big Bang (Recomendado para Times Pequenos)
**Duração:** 1 dia  
**Abordagem:** Migrar tudo de uma vez em janela dedicada

**Prós:**
- ✅ Rápido
- ✅ Todo mundo na mesma versão
- ✅ Sem confusão v1/v2

**Contras:**
- ❌ Requer parada de trabalho
- ❌ Risco se algo der errado

---

### Estratégia 2: Incremental (Recomendado para Times Grandes)
**Duração:** 2-4 semanas  
**Abordagem:** Migrar por agente/fluxo

**Semana 1:** Migrar João (PM) - PRDs v2.0  
**Semana 2:** Migrar Wilson (Architect) - Arquiteturas v2.0  
**Semana 3:** Migrar Roberto/Paula - Stories v2.0  
**Semana 4:** Migrar Tiago/Carla/Sofia - Dev/QA/UX v2.0

**Prós:**
- ✅ Menos disruptivo
- ✅ Aprendizado gradual
- ✅ Risco mitigado

**Contras:**
- ❌ Mais longo
- ❌ Convivência v1/v2 temporária

---

### Estratégia 3: Projeto Piloto
**Duração:** 1 projeto completo  
**Abordagem:** Novo projeto usa v2.0, legado continua v1.0

**Prós:**
- ✅ Zero risco para projetos em andamento
- ✅ Validação real de v2.0
- ✅ Aprendizado prático

**Contras:**
- ❌ Mais lento
- ❌ Duplicação de esforço (v1 e v2)

---

## 💡 Dicas de Sucesso

### Para Product Managers
```
💡 João v2.0 faz perguntas estruturadas ANTES de gerar PRD.
   Não force ele a gerar imediatamente - responda as perguntas.
   Resultado: PRD muito mais completo.
```

### Para Architects
```
💡 Wilson v2.0 tem ADVERSARIAL_REVIEW.
   Use-o como "second opinion" antes de apresentar arquitetura.
   Ele vai questionar decisões - é proposital!
```

### Para Scrum Masters
```
💡 Roberto v2.0 valida INVEST automaticamente.
   Rode STORY_READINESS antes de Sprint Planning.
   Evita stories mal definidas entrando no sprint.
```

### Para Desenvolvedores
```
💡 Tiago v2.0 tem CLEAN_CODE e CODE_REVIEW tasks.
   Use antes de criar PR - feedback imediato.
   Menos idas e vindas no review humano.
```

---

## 🐛 Troubleshooting

### Problema: Menu v2.0 não aparece
**Sintomas:** Agente responde em texto livre, sem menu

**Soluções:**
1. Verificar versão do MCP server
   ```bash
   npm list @avanade/method-mcp-server
   # Deve ser >= 2.0.0
   ```

2. Limpar cache
   ```bash
   rm -rf .avanade-method/.cache
   ```

3. Re-ativar agente
   ```
   #avanade-method
   > Supervisor
   > João
   ```

---

### Problema: Artefatos v1.0 não validam
**Sintomas:** Task de validação falha em PRD v1.0

**Soluções:**
1. PRD v1.0 pode não ter seções obrigatórias v2.0
2. Opção A: João atualiza automaticamente (recomendado)
3. Opção B: Adicionar seções manualmente e re-validar

---

### Problema: Memória não funciona
**Sintomas:** João repete perguntas já respondidas

**Soluções:**
1. Verificar persistência de memória habilitada
2. Verificar path de memória configurado
3. Re-configurar preferências manualmente

---

## 📞 Suporte

### Recursos de Ajuda

**Documentação:**
- [README Principal](../README.md)
- [Documentação de Agentes](../agents/)
- [Sistema de Artefatos](../artifacts/system-overview.md)

**Comando In-App:**
```
/avanade-help migration
```

**Contato:**
- Equipe de Platform Engineering
- Canal Slack: #avanade-method-v2
- Email: platform-eng@avanade.com

---

## 🎉 Sucesso da Migração

Você completou a migração quando:

- ✅ Menu v2.0 aparece em todos os agentes
- ✅ Workflows executam corretamente
- ✅ Tasks de validação funcionam
- ✅ Memória persiste preferências
- ✅ Party Mode funciona
- ✅ Time treinado e confortável

**Parabéns! Você está em CODE v2.0! 🚀**

---

## 📈 Próximos Passos

Após migração completa:

1. **Monitorar Uso** (Semana 1)
   - Acompanhar adoção
   - Coletar feedback inicial
   - Ajustar preferências

2. **Otimizar** (Semana 2-4)
   - Configurar templates customizados
   - Refinar memória de agentes
   - Criar workflows específicos do time

3. **Escalar** (Mês 2+)
   - Compartilhar melhores práticas
   - Documentar casos de uso
   - Contribuir com feedback para v2.1

---

**Versão:** 2.0.0  
**Última Atualização:** Fevereiro 2026  
**Tempo Médio de Migração:** 2-4 horas  
**Taxa de Sucesso:** 98%
