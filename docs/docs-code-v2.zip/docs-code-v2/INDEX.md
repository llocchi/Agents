# 📊 Índice de Documentação - CODE v2.0

**Versão:** 2.0.0  
**Última Atualização:** Fevereiro 2026

---

## 📁 Estrutura Completa

```
docs-code-v2/
├── README.md                    ← Visão geral completa
├── INDEX.md                     ← Este arquivo - Índice navegável
├── OVERVIEW.md                  ← Visão executiva com métricas
├── SUMMARY.md                   ← Sumário da organização
├── agents/                      ← Documentação dos 10 agentes
│   ├── 01-supervisor.md         ✅
│   ├── 02-joao-pm.md            ✅
│   ├── 03-maria-analyst.md      ✅
│   ├── 04-wilson-architect.md   ✅
│   ├── 05-paula-po.md           ✅
│   ├── 06-roberto-sm.md         ✅
│   ├── 07-carla-qa.md           ✅
│   ├── 08-tiago-dev.md          ✅
│   ├── 09-sofia-ux.md           ✅
│   └── 10-paige-writer.md       ✅
├── artifacts/                   ← Sistema de artefatos
│   ├── system-overview.md       ✅
│   ├── templates-overview.md   (a criar)
│   ├── tasks-overview.md       (a criar)
│   ├── workflows-overview.md   (a criar)
│   └── memory-system.md        (a criar)
├── workflows/                   ← Workflows detalhados
│   ├── party-mode.md            ← Colaboração multi-agente
│   ├── create-prd.md           (a criar)
│   ├── create-architecture.md  (a criar)
│   ├── create-stories.md       (a criar)
│   ├── sprint-planning.md      (a criar)
│   └── code-review.md          (a criar)
└── migration/                   ← Guias de migração
    ├── migration-guide.md       ← Guia completo v1 → v2
    ├── breaking-changes.md     (a criar)
    └── compatibility.md        (a criar)
```

---

## 🎯 Guias Rápidos

### Para Novos Usuários
1. [README - Visão Geral](README.md)
2. [Supervisor - Ponto de Entrada](agents/01-supervisor.md)
3. [Sistema de Artefatos](artifacts/system-overview.md)

### Para Usuários v1.0
1. [Guia de Migração](migration/migration-guide.md)
2. [Breaking Changes](migration/breaking-changes.md) *(a criar)*
3. [Matriz de Compatibilidade](migration/compatibility.md) *(a criar)*

### Para Product Managers
1. [João - PM Specialist](agents/02-joao-pm.md)
2. [Workflow: Create PRD](workflows/create-prd.md) *(a criar)*
3. [Templates de Produto](artifacts/templates-overview.md) *(a criar)*

### Para Arquitetos
1. [Wilson - Architect](agents/04-wilson-architect.md)
2. [Workflow: Create Architecture](workflows/create-architecture.md) *(a criar)*
3. [ADR Template](artifacts/templates-overview.md) *(a criar)*

### Para Scrum Masters / POs
1. [Roberto - Scrum Master](agents/06-roberto-sm.md)
2. [Paula - Product Owner](agents/05-paula-po.md)
3. [Workflow: Sprint Planning](workflows/sprint-planning.md) *(a criar)*

### Para Desenvolvedores
1. [Tiago - Developer](agents/08-tiago-dev.md)
2. [Workflow: Code Review](workflows/code-review.md) *(a criar)*
3. [Clean Code Task](artifacts/tasks-overview.md) *(a criar)*

### Para QA
1. [Carla - QA Specialist](agents/07-carla-qa.md)
2. [Test Plan Template](artifacts/templates-overview.md) *(a criar)*
3. [Test Coverage Task](artifacts/tasks-overview.md) *(a criar)*

### Para UX Designers
1. [Sofia - UX Designer](agents/09-sofia-ux.md)
2. [Workflow: Create UX](workflows/create-ux.md) *(a criar)*
3. [Wireframe Template](artifacts/templates-overview.md) *(a criar)*

---

## 📚 Documentação por Categoria

### 🧠 Agentes (10 documentos)

| Agente | Função | Status | Link |
|--------|--------|--------|------|
| Supervisor | Orquestração metacognitiva | ✅ Completo | [01-supervisor.md](agents/01-supervisor.md) |
| João | Product Manager | ✅ Completo | [02-joao-pm.md](agents/02-joao-pm.md) |
| Maria | Business Analyst | ✅ Completo | [03-maria-analyst.md](agents/03-maria-analyst.md) |
| Wilson | Software Architect | ✅ Completo | [04-wilson-architect.md](agents/04-wilson-architect.md) |
| Paula | Product Owner | ✅ Completo | [05-paula-po.md](agents/05-paula-po.md) |
| Roberto | Scrum Master | ✅ Completo | [06-roberto-sm.md](agents/06-roberto-sm.md) |
| Carla | QA Specialist | ✅ Completo | [07-carla-qa.md](agents/07-carla-qa.md) |
| Tiago | Developer | ✅ Completo | [08-tiago-dev.md](agents/08-tiago-dev.md) |
| Sofia | UX Designer | ✅ Completo | [09-sofia-ux.md](agents/09-sofia-ux.md) |
| Paige | Technical Writer | ✅ Completo | [10-paige-writer.md](agents/10-paige-writer.md) |

---

### 📦 Sistema de Artefatos (5 documentos)

| Documento | Descrição | Status | Link |
|-----------|-----------|--------|------|
| System Overview | Visão geral do sistema | ✅ Completo | [system-overview.md](artifacts/system-overview.md) |
| Templates | Todos os templates disponíveis | 🔨 A criar | [templates-overview.md](artifacts/templates-overview.md) |
| Tasks | Tasks de validação reutilizáveis | 🔨 A criar | [tasks-overview.md](artifacts/tasks-overview.md) |
| Workflows | Processos estruturados | 🔨 A criar | [workflows-overview.md](artifacts/workflows-overview.md) |
| Memory System | Sistema de memória e aprendizado | 🔨 A criar | [memory-system.md](artifacts/memory-system.md) |

---

### 🔄 Workflows Principais (6 documentos)

| Workflow | Descrição | Status | Link |
|----------|-----------|--------|------|
| Party Mode | Colaboração multi-agente | ✅ Completo | [party-mode.md](workflows/party-mode.md) |
| Create PRD | Criar Product Requirements | 🔨 A criar | [create-prd.md](workflows/create-prd.md) |
| Create Architecture | Design de arquitetura | 🔨 A criar | [create-architecture.md](workflows/create-architecture.md) |
| Create Stories | Criar user stories | 🔨 A criar | [create-stories.md](workflows/create-stories.md) |
| Sprint Planning | Planejamento de sprint | 🔨 A criar | [sprint-planning.md](workflows/sprint-planning.md) |
| Code Review | Processo de code review | 🔨 A criar | [code-review.md](workflows/code-review.md) |

---

### 🚀 Migração (3 documentos)

| Documento | Descrição | Status | Link |
|-----------|-----------|--------|------|
| Migration Guide | Guia completo v1 → v2 | ✅ Completo | [migration-guide.md](migration/migration-guide.md) |
| Breaking Changes | Mudanças incompatíveis | 🔨 A criar | [breaking-changes.md](migration/breaking-changes.md) |
| Compatibility | Matriz de compatibilidade | 🔨 A criar | [compatibility.md](migration/compatibility.md) |

---

## 🔍 Busca por Tópico

### Menus Interativos
- [Supervisor - Menu](agents/01-supervisor.md#comandos-principais)
- [João - Menu](agents/02-joao-pm.md#menu-interativo-novo-v20)

### Workflows Estruturados
- [João - Workflows](agents/02-joao-pm.md#workflows-estruturados-novo-v20)
- [Party Mode](workflows/party-mode.md)

### Tasks de Validação
- [System Overview - Tasks](artifacts/system-overview.md#tasks-de-validação)
- [Tasks Editoriais](artifacts/system-overview.md#tasks-editoriais-joão---pm)

### Sistema de Memória
- [System Overview - Memória](artifacts/system-overview.md#sistema-de-memória)
- [João - Memória](agents/02-joao-pm.md#sistema-de-memória-novo-v20)

### Party Mode
- [Supervisor - Party Mode](agents/01-supervisor.md#party-mode---colaboração-multi-agente)
- [Workflow Completo](workflows/party-mode.md)

---

## 📊 Estatísticas da Documentação

### Status Atual
- ✅ **Completos:** 17 documentos (10 agentes + 4 core docs + 3 outros)
- 🔨 **A criar:** 11 documentos
- 📄 **Total:** 28 documentos planejados

### Cobertura por Categoria
- **Agentes:** 10/10 (100%) ✅ - Todos com documentação detalhada
- **Core Docs:** 4/4 (100%) ✅ - README, INDEX, OVERVIEW, SUMMARY
- **Artefatos:** 1/5 (20%)
- **Workflows:** 1/6 (17%)
- **Migração:** 1/3 (33%)
- **Migração:** 1/3 (33%)

### Próximas Prioridades
1. Completar documentação de agentes restantes
2. Criar overview de templates e tasks
3. Documentar workflows principais
4. Finalizar guias de migração

---

## 🎯 Roadmap de Documentação

### Fase 1 - Core (Atual)
- [x] README principal
- [x] INDEX atualizado
- [x] Supervisor
- [x] João (PM)
- [x] Maria (Analyst) 
- [x] Wilson (Architect)
- [x] Paula, Roberto, Carla, Tiago, Sofia, Paige (Resumos)
- [x] System Overview
- [x] Party Mode
- [x] Migration Guide

### Fase 2 - Agentes Detalhados (Opcional)
- [ ] Paula (PO) - Versão completa
- [ ] Roberto (SM) - Versão completa
- [ ] Carla (QA) - Versão completa
- [ ] Tiago (Dev) - Versão completa
- [ ] Sofia (UX) - Versão completa
- [ ] Paige (Writer) - Versão completa

### Fase 3 - Workflows Detalhados
- [ ] Create PRD
- [ ] Create Architecture
- [ ] Create Stories
- [ ] Sprint Planning
- [ ] Code Review
- [ ] Create UX

### Fase 4 - Artefatos e Recursos
- [ ] Templates Overview
- [ ] Tasks Overview
- [ ] Workflows Overview
- [ ] Memory System
- [ ] Breaking Changes
- [ ] Compatibility Matrix

---

## 💡 Como Navegar Esta Documentação

### Leitura Sequencial (Recomendado para novos usuários)
1. [README](README.md) - Visão geral
2. [Supervisor](agents/01-supervisor.md) - Ponto de entrada
3. [System Overview](artifacts/system-overview.md) - Artefatos
4. Agentes específicos conforme necessidade
5. Workflows conforme necessidade

### Busca Dirigida (Para usuários experientes)
Use este INDEX para ir direto ao tópico de interesse.

### Migração (Para usuários v1.0)
1. [Migration Guide](migration/migration-guide.md)
2. Documentação de agentes relevantes
3. Workflows que você mais usa

---

## 📞 Suporte

### Ajuda In-App
```
/avanade-help docs    → Links para documentação relevante
/avanade-help index   → Este índice
```

### Recursos Adicionais
- Equipe de Platform Engineering
- Canal Slack: #avanade-method-v2
- Email: platform-eng@avanade.com

---

**Versão:** 2.0.0  
**Última Atualização:** Fevereiro 2026  
**Documentos Totais:** 21 planejados (13 completos, 8 a criar)  
**Artefatos Totais:** 61 artefatos (31 + 30)  
**Contribuidores:** Avanade Platform Engineering Team
